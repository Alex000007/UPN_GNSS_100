from django.db import models


class Article(models.Model):
	article_title = models.CharField('nazvanie', max_length = 200)
	article_text = models.TextField('text stati')
	pub_date = models.DateTimeField('data pyblikatcii')

class Comment(models.Model):
		article = models.ForeignKey(Article, on_delete = models.CASCADE)
		author_name = models.CharField('author`s name', max_length = 50)
		comment_text = models.CharField('comentarii', max_length = 200)