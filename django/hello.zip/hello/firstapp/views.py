from django.http import HttpResponse
from .forms import UserForm

from django.shortcuts import render
from firstapp.models import Article,Comment



"""def car_detail(request, pk):
	owner_obj = Driver.objects.get(pk=pk)
	car_objs = Car.objects.filter(owner_id=owner_obj.id)
	context = {
		"vehicles":car_objs,
		"drivers":owner_obj,

	}

	return render(request,"about.html", context)"""



def index(request):
	if request.method == "POST":
		name = request.POST.get("name")
		# age = request.POST.get("age")		#получения значения поля age
		return HttpResponse("<h2>Hello, {0}</h2>".format(name))
	else:
		userform = UserForm()
		return render(request, "index.html", {"form": userform})



"""def index(request):
	langs = ["English", "German", "French", "Spanish", "Chinese"]
	data = {"n": 0}
	return render(request, "index.html", context={"langs": langs})
	return render(request, "index.html",context=data)"""







"""def mainpage(request):
	return HttpResponse("Main page")

def about(request):
	return HttpResponse("About")

def contact(request):
	return HttpResponseRedirect("/about")

def details(request):
	return HttpResponsePermanentRedirect("/")
"""



"""def products(request, productid = 21):
	output = "<h2>Product № {0}</h2>".format(productid)
	return HttpResponse(output)

def users(request, id = 1, name= "Ron"):
	output = "<h2>User</h2><h3>id: {0} name: {1}</h3>".format(id,name)
	return HttpResponse (output)
"""



"""def index(request):
	return HttpResponse("<h2>Main page!</h2>")

def about(request):
	return HttpResponse("<h2>about</h2>")

def contact(request):
	return HttpResponse("<h2>Contacts</h2>")

"""
